from rest_framework import viewsets
from .models import Companies 
from .serializers import CompanySerializer

class CompanyViewSet(viewsets.ModelViewSet):
    queryset = companies.objects.all().order_by('id')
    serializers_class = CompanySerializer